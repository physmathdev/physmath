# TubeReplacer 2.0.1 — iOS 10: вход, подписки и рекомендации

## Что исправлено в этой сборке (2.0.1-2)
- Вход в Google не падает в AppleSpell на iOS 10 (отдельный `TubeReplacerSpellFix.dylib`).
- Главная страница и «Подписки» теперь понимают современные ответы YouTube:
  `twoColumnBrowseResultsRenderer`, `richSectionRenderer`, `shelfRenderer`,
  `expandedShelfContentsRenderer`, `verticalListRenderer`, `richItemRenderer`.
- Список подписок (`FEchannels`) читается из `channelRenderer` и его новых вариантов,
  а не только из старого `channelListItemRenderer`.
- Запросы следующей страницы ленты отправляются с той же авторизацией, что и первый
  запрос, поэтому прокрутка не должна обрывать ленту.
- Плеер и вход не переписывались: исправления касаются разбора лент и авторизации
  продолжений.

## Готовый пакет
`dist/dev.preloading.tubereplacer_2.0.1-2_iphoneos-arm.deb`

## Установка
1. Установите .deb через Filza / Cydia / Zebra / Sileo (rootful, iOS 10).
   Пакет имеет то же имя, что и 2.0.1, и версию 2.0.1-2.
2. Сделайте respring (или перезагрузите устройство).
3. Запустите YouTube и проверьте вход, «Главную» и «Подписки».

Если менеджер откажется ставить локальный файл из-за версии, установите через SSH:
```
dpkg -i /path/to/dev.preloading.tubereplacer_2.0.1-2_iphoneos-arm.deb
killall -9 YouTube
```

## Если подписки или рекомендации всё ещё пустые
1. Включите в настройках TubeReplacer `DebugNetworkRequests`.
2. Откройте «Главную» и «Подписки», прокрутите ленту.
3. Пришлите файл:
   `/var/mobile/Library/Preferences/tubereplacer_network_log.txt`
   (и, если есть, свежий crash log YouTube).

По этому логу можно точно увидеть, приходит ли контент от YouTube и в каком
renderer-формате.

## Проверка, что фикс входа загрузился
В Console.app / idevicesyslog:
```
TubeReplacerSpellFix: hooked languageModelForLanguage:appIdentifier:waitForResult:
TubeReplacerSpellFix: initialized
```

## Технические детали
- `TubeReplacerGoogle.dylib` пересобран из тега 2.0.1 с исправлениями разбора лент.
- Архитектуры: armv7 + arm64; фильтр загрузки поддерживает YouTube 2.0.0 и 2.0.1.
- Preference bundle и HTML-ресурсы взяты из оригинального пакета.
- `TubeReplacerSpellFix.dylib` — отдельный твик только для обхода падения AppleSpell
  при входе; обычная проверка орфографии не отключается.
- Старые жёстко заданные playlist ID вкладок категорий YouTube уже удалил.
  Это не влияет на «Главную» и «Подписки»; категории при необходимости чинятся отдельно.
